<?php
$nombre=$_POST["usuario"];
$pass=$_POST["pass"];

echo "ya estamos programando php <br>";
echo "bienvenido ".$nombre." tu contraseña es ".$pass; 
?>

